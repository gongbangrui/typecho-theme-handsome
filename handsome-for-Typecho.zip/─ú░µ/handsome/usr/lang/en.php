<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * en.php
 * Author     : hewro
 * Date       : 2017/04/30
 * Version    :
 * Description:
 */
class Usr_Lang_en extends Lang_en {

    /**
     * @return array 返回包含翻译文本的数组
     */
    public function translated() {
        return array(
            
        );
    }

    public function dateFormat() {
       // return "m 月 d 日 Y 年 ";
    }

}
